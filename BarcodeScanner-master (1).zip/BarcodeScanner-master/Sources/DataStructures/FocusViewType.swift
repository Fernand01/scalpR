import UIKit

/// Type of the focus view
public enum FocusViewType {
  case animated
  case oneDimension
  case twoDimensions
}
